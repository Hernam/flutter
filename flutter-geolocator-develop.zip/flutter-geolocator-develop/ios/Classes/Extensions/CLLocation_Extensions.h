//
//  CLLocation_Extensions.h
//  Pods
//
//  Created by Maurits van Beusekom on 20/05/2019.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface CLLocation (CLLocation_Extension)
- (NSDictionary *)toDictionary;
@end
